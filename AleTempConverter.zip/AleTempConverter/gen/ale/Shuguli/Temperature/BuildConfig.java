/** Automatically generated file. DO NOT MODIFY */
package ale.Shuguli.Temperature;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}